import React from 'react';
import { Issue } from '../types';
import { Clock, User, AlertCircle, CheckCircle, Hourglass } from 'lucide-react';

interface IssueCardProps {
  issue: Issue;
  onResolve?: (issueId: string, resolution: string) => void;
  onUpdate?: (issueId: string, status: string, resolution?: string) => void;
  showActions?: boolean;
}

const IssueCard: React.FC<IssueCardProps> = ({ issue, onResolve, onUpdate, showActions = false }) => {
  const [showResolveForm, setShowResolveForm] = React.useState(false);
  const [resolution, setResolution] = React.useState('');
  const [showUpdateForm, setShowUpdateForm] = React.useState(false);
  const [updateStatus, setUpdateStatus] = React.useState(issue.status);
  const [updateResolution, setUpdateResolution] = React.useState(issue.resolution || '');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'In Progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Resolved': return 'bg-green-100 text-green-800 border-green-200';
      case 'Waiting': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Open': return <AlertCircle className="w-4 h-4" />;
      case 'In Progress': return <Clock className="w-4 h-4" />;
      case 'Resolved': return <CheckCircle className="w-4 h-4" />;
      case 'Waiting': return <Hourglass className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const handleResolve = () => {
    if (resolution.trim() && onResolve) {
      onResolve(issue.id, resolution);
      setShowResolveForm(false);
      setResolution('');
    }
  };

  const handleUpdate = () => {
    if (onUpdate) {
      onUpdate(issue.id, updateStatus, updateResolution);
      setShowUpdateForm(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <span className="text-sm font-mono text-gray-500">#{issue.id}</span>
          <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(issue.status)}`}>
            {getStatusIcon(issue.status)}
            <span>{issue.status}</span>
          </span>
        </div>
        <span className="text-xs text-gray-500">
          {issue.createdAt.toLocaleString()}
        </span>
      </div>

      <div className="space-y-3">
        <div>
          <h3 className="font-semibold text-gray-900 mb-1">{issue.subject}</h3>
          <p className="text-sm text-gray-600">{issue.description}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500">Transaction ID:</span>
            <p className="font-mono text-gray-900">{issue.transactionId}</p>
          </div>
          <div>
            <span className="text-gray-500">Issue Type:</span>
            <p className="text-gray-900">{issue.issueType}</p>
          </div>
          <div>
            <span className="text-gray-500">Customer Email:</span>
            <p className="text-gray-900">{issue.email}</p>
          </div>
          {issue.assignedTo && (
            <div>
              <span className="text-gray-500">Assigned Agent:</span>
              <p className="text-gray-900 flex items-center">
                <User className="w-3 h-3 mr-1" />
                {issue.assignedTo}
              </p>
            </div>
          )}
        </div>

        {issue.resolution && (
          <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-md">
            <span className="text-sm font-medium text-green-800">Resolution:</span>
            <p className="text-sm text-green-700 mt-1">{issue.resolution}</p>
          </div>
        )}

        {showActions && issue.status !== 'Resolved' && (
          <div className="mt-4 flex space-x-2">
            {issue.status === 'In Progress' && (
              <button
                onClick={() => setShowResolveForm(true)}
                className="px-3 py-2 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors"
              >
                Resolve Issue
              </button>
            )}
            <button
              onClick={() => setShowUpdateForm(true)}
              className="px-3 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors"
            >
              Update Status
            </button>
          </div>
        )}

        {showResolveForm && (
          <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-md">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Resolve Issue</h4>
            <textarea
              value={resolution}
              onChange={(e) => setResolution(e.target.value)}
              placeholder="Enter resolution details..."
              className="w-full p-2 border border-gray-300 rounded-md text-sm"
              rows={3}
            />
            <div className="mt-2 flex space-x-2">
              <button
                onClick={handleResolve}
                className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
              >
                Resolve
              </button>
              <button
                onClick={() => setShowResolveForm(false)}
                className="px-3 py-1 bg-gray-300 text-gray-700 text-xs rounded hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {showUpdateForm && (
          <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-md">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Update Status</h4>
            <div className="space-y-2">
              <select
                value={updateStatus}
                onChange={(e) => setUpdateStatus(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="Open">Open</option>
                <option value="In Progress">In Progress</option>
                <option value="Waiting">Waiting</option>
              </select>
              <textarea
                value={updateResolution}
                onChange={(e) => setUpdateResolution(e.target.value)}
                placeholder="Add notes or resolution details..."
                className="w-full p-2 border border-gray-300 rounded-md text-sm"
                rows={2}
              />
            </div>
            <div className="mt-2 flex space-x-2">
              <button
                onClick={handleUpdate}
                className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
              >
                Update
              </button>
              <button
                onClick={() => setShowUpdateForm(false)}
                className="px-3 py-1 bg-gray-300 text-gray-700 text-xs rounded hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default IssueCard;