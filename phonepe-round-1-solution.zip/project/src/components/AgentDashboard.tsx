import React, { useState } from 'react';
import { Agent, Issue, IssueFilter } from '../types';
import IssueCard from './IssueCard';
import { Search, User, Clock, CheckCircle } from 'lucide-react';

interface AgentDashboardProps {
  agents: Agent[];
  issues: Issue[];
  onSearch: (filter: IssueFilter) => Issue[];
  onResolveIssue: (issueId: string, resolution: string) => void;
  onUpdateIssue: (issueId: string, status: string, resolution?: string) => void;
  getWaitlist: (agentId: string) => Issue[];
}

const AgentDashboard: React.FC<AgentDashboardProps> = ({
  agents,
  issues,
  onSearch,
  onResolveIssue,
  onUpdateIssue,
  getWaitlist,
}) => {
  const [selectedAgent, setSelectedAgent] = useState<string>('');
  const [searchFilter, setSearchFilter] = useState<IssueFilter>({});
  const [searchResults, setSearchResults] = useState<Issue[]>([]);
  const [activeTab, setActiveTab] = useState<'assigned' | 'search' | 'waitlist'>('assigned');

  const handleSearch = () => {
    const results = onSearch(searchFilter);
    setSearchResults(results);
  };

  const getAgentIssues = (agentId: string) => {
    return issues.filter(issue => issue.assignedTo === agentId);
  };

  const selectedAgentData = agents.find(agent => agent.id === selectedAgent);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
        <div className="flex items-center space-x-2 mb-4">
          <User className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Agent Dashboard</h2>
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Agent
          </label>
          <select
            value={selectedAgent}
            onChange={(e) => setSelectedAgent(e.target.value)}
            className="w-full md:w-64 p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Choose an agent</option>
            {agents.map(agent => (
              <option key={agent.id} value={agent.id}>
                {agent.name} ({agent.id})
              </option>
            ))}
          </select>
        </div>

        {selectedAgentData && (
          <div className="bg-gray-50 border border-gray-200 rounded-md p-4 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <span className="text-sm text-gray-500">Agent Name:</span>
                <p className="font-medium text-gray-900">{selectedAgentData.name}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Email:</span>
                <p className="font-medium text-gray-900">{selectedAgentData.email}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Expertise:</span>
                <p className="font-medium text-gray-900">
                  {selectedAgentData.expertise.join(', ')}
                </p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Current Status:</span>
                <p className={`font-medium ${selectedAgentData.currentIssue ? 'text-orange-600' : 'text-green-600'}`}>
                  {selectedAgentData.currentIssue ? `Working on ${selectedAgentData.currentIssue}` : 'Available'}
                </p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Total Cases Handled:</span>
                <p className="font-medium text-gray-900">{selectedAgentData.workHistory.length}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex space-x-1 mb-4">
          <button
            onClick={() => setActiveTab('assigned')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'assigned'
                ? 'bg-blue-100 text-blue-700 border border-blue-200'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Assigned Issues
          </button>
          <button
            onClick={() => setActiveTab('search')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'search'
                ? 'bg-blue-100 text-blue-700 border border-blue-200'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Search Issues
          </button>
          <button
            onClick={() => setActiveTab('waitlist')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'waitlist'
                ? 'bg-blue-100 text-blue-700 border border-blue-200'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Waitlist
          </button>
        </div>
      </div>

      {activeTab === 'search' && (
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Search className="w-5 h-5 text-gray-600" />
            <h3 className="text-lg font-medium text-gray-900">Search Issues</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <input
              type="text"
              placeholder="Issue ID"
              value={searchFilter.issueId || ''}
              onChange={(e) => setSearchFilter(prev => ({ ...prev, issueId: e.target.value }))}
              className="p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <input
              type="email"
              placeholder="Customer Email"
              value={searchFilter.email || ''}
              onChange={(e) => setSearchFilter(prev => ({ ...prev, email: e.target.value }))}
              className="p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <select
              value={searchFilter.type || ''}
              onChange={(e) => setSearchFilter(prev => ({ ...prev, type: e.target.value as any }))}
              className="p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">All Types</option>
              <option value="Payment Related">Payment Related</option>
              <option value="Mutual Fund Related">Mutual Fund Related</option>
              <option value="Gold Related">Gold Related</option>
              <option value="Insurance Related">Insurance Related</option>
            </select>
            <button
              onClick={handleSearch}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Search className="w-4 h-4" />
              <span>Search</span>
            </button>
          </div>

          <div className="space-y-4">
            {searchResults.map(issue => (
              <IssueCard
                key={issue.id}
                issue={issue}
                onResolve={onResolveIssue}
                onUpdate={onUpdateIssue}
                showActions={issue.assignedTo === selectedAgent}
              />
            ))}
            {searchResults.length === 0 && (
              <p className="text-gray-500 text-center py-8">No issues found matching your search criteria.</p>
            )}
          </div>
        </div>
      )}

      {activeTab === 'assigned' && selectedAgent && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900 flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Assigned Issues</span>
          </h3>
          {getAgentIssues(selectedAgent).map(issue => (
            <IssueCard
              key={issue.id}
              issue={issue}
              onResolve={onResolveIssue}
              onUpdate={onUpdateIssue}
              showActions={true}
            />
          ))}
          {getAgentIssues(selectedAgent).length === 0 && (
            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-8 text-center">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <p className="text-gray-500">No assigned issues. You're all caught up!</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'waitlist' && selectedAgent && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900 flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Waitlist</span>
          </h3>
          {getWaitlist(selectedAgent).map(issue => (
            <IssueCard
              key={issue.id}
              issue={issue}
            />
          ))}
          {getWaitlist(selectedAgent).length === 0 && (
            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-8 text-center">
              <p className="text-gray-500">No issues in waitlist.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AgentDashboard;