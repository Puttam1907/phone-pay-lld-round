import React, { useState } from 'react';
import { CreateIssueData, IssueType } from '../types';
import { AlertTriangle, Send } from 'lucide-react';

interface CustomerFormProps {
  onCreateIssue: (data: CreateIssueData) => void;
}

const CustomerForm: React.FC<CustomerFormProps> = ({ onCreateIssue }) => {
  const [formData, setFormData] = useState<CreateIssueData>({
    transactionId: '',
    issueType: 'Payment Related',
    subject: '',
    description: '',
    email: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const issueTypes: IssueType[] = [
    'Payment Related',
    'Mutual Fund Related',
    'Gold Related',
    'Insurance Related',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.transactionId || !formData.subject || !formData.description || !formData.email) {
      return;
    }

    setIsSubmitting(true);
    try {
      onCreateIssue(formData);
      setFormData({
        transactionId: '',
        issueType: 'Payment Related',
        subject: '',
        description: '',
        email: '',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: keyof CreateIssueData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <AlertTriangle className="w-6 h-6 text-orange-600" />
        <h2 className="text-xl font-semibold text-gray-900">Report an Issue</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Transaction ID *
            </label>
            <input
              type="text"
              value={formData.transactionId}
              onChange={(e) => handleChange('transactionId', e.target.value)}
              placeholder="Enter transaction ID (e.g., T1, T2)"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Issue Type *
            </label>
            <select
              value={formData.issueType}
              onChange={(e) => handleChange('issueType', e.target.value as IssueType)}
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {issueTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email Address *
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            placeholder="Enter your email address"
            className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Subject *
          </label>
          <input
            type="text"
            value={formData.subject}
            onChange={(e) => handleChange('subject', e.target.value)}
            placeholder="Brief description of the issue"
            className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description *
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => handleChange('description', e.target.value)}
            placeholder="Provide detailed information about the issue"
            rows={4}
            className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          <Send className="w-4 h-4" />
          <span>{isSubmitting ? 'Submitting...' : 'Submit Issue'}</span>
        </button>
      </form>
    </div>
  );
};

export default CustomerForm;