import React, { useState } from 'react';
import { Agent, Issue, CreateAgentData, IssueType } from '../types';
import { Settings, UserPlus, BarChart3, Users } from 'lucide-react';

interface AdminPanelProps {
  agents: Agent[];
  onAddAgent: (data: CreateAgentData) => void;
  getWorkHistory: () => { agent: Agent; issues: Issue[] }[];
  getStats: () => any;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ agents, onAddAgent, getWorkHistory, getStats }) => {
  const [activeTab, setActiveTab] = useState<'agents' | 'history' | 'stats'>('agents');
  const [showAddAgent, setShowAddAgent] = useState(false);
  const [newAgent, setNewAgent] = useState<CreateAgentData>({
    email: '',
    name: '',
    expertise: [],
  });

  const issueTypes: IssueType[] = [
    'Payment Related',
    'Mutual Fund Related',
    'Gold Related',
    'Insurance Related',
  ];

  const handleAddAgent = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAgent.email && newAgent.name && newAgent.expertise.length > 0) {
      onAddAgent(newAgent);
      setNewAgent({ email: '', name: '', expertise: [] });
      setShowAddAgent(false);
    }
  };

  const handleExpertiseChange = (type: IssueType, checked: boolean) => {
    setNewAgent(prev => ({
      ...prev,
      expertise: checked 
        ? [...prev.expertise, type]
        : prev.expertise.filter(t => t !== type)
    }));
  };

  const workHistory = getWorkHistory();
  const stats = getStats();

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Settings className="w-6 h-6 text-indigo-600" />
            <h2 className="text-xl font-semibold text-gray-900">Admin Panel</h2>
          </div>
          {activeTab === 'agents' && (
            <button
              onClick={() => setShowAddAgent(true)}
              className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors flex items-center space-x-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add Agent</span>
            </button>
          )}
        </div>

        <div className="flex space-x-1 mb-6">
          <button
            onClick={() => setActiveTab('agents')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'agents'
                ? 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Users className="w-4 h-4 inline mr-2" />
            Agents
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'history'
                ? 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Work History
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'stats'
                ? 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <BarChart3 className="w-4 h-4 inline mr-2" />
            Statistics
          </button>
        </div>

        {showAddAgent && (
          <div className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-md">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Add New Agent</h3>
            <form onSubmit={handleAddAgent} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                  <input
                    type="text"
                    value={newAgent.name}
                    onChange={(e) => setNewAgent(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                  <input
                    type="email"
                    value={newAgent.email}
                    onChange={(e) => setNewAgent(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Expertise *</label>
                <div className="grid grid-cols-2 gap-2">
                  {issueTypes.map(type => (
                    <label key={type} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={newAgent.expertise.includes(type)}
                        onChange={(e) => handleExpertiseChange(type, e.target.checked)}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-gray-700">{type}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  type="submit"
                  className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors"
                >
                  Add Agent
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddAgent(false)}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {activeTab === 'agents' && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900">All Agents</h3>
            <div className="grid gap-4">
              {agents.map(agent => (
                <div key={agent.id} className="border border-gray-200 rounded-md p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">{agent.name}</h4>
                      <p className="text-sm text-gray-500">{agent.email}</p>
                      <div className="mt-2">
                        <span className="text-xs text-gray-500">Expertise: </span>
                        <span className="text-xs text-gray-700">{agent.expertise.join(', ')}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${
                        agent.currentIssue ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                      }`}>
                        {agent.currentIssue ? 'Busy' : 'Available'}
                      </span>
                      <p className="text-xs text-gray-500 mt-1">
                        {agent.workHistory.length} cases handled
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900">Work History</h3>
            <div className="space-y-4">
              {workHistory.map(({ agent, issues }) => (
                <div key={agent.id} className="border border-gray-200 rounded-md p-4">
                  <h4 className="font-medium text-gray-900 mb-2">
                    {agent.name} ({agent.id}) - {issues.length} issues handled
                  </h4>
                  <div className="space-y-2">
                    {issues.slice(0, 5).map(issue => (
                      <div key={issue.id} className="text-sm text-gray-600 flex justify-between">
                        <span>#{issue.id} - {issue.subject}</span>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          issue.status === 'Resolved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {issue.status}
                        </span>
                      </div>
                    ))}
                    {issues.length > 5 && (
                      <p className="text-xs text-gray-500">... and {issues.length - 5} more</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="space-y-6">
            <h3 className="text-lg font-medium text-gray-900">System Statistics</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                <div className="text-2xl font-bold text-blue-700">{stats.totalIssues}</div>
                <div className="text-sm text-blue-600">Total Issues</div>
              </div>
              <div className="bg-orange-50 border border-orange-200 rounded-md p-4">
                <div className="text-2xl font-bold text-orange-700">{stats.openIssues}</div>
                <div className="text-sm text-orange-600">Open Issues</div>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-md p-4">
                <div className="text-2xl font-bold text-purple-700">{stats.inProgressIssues}</div>
                <div className="text-sm text-purple-600">In Progress</div>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-md p-4">
                <div className="text-2xl font-bold text-green-700">{stats.resolvedIssues}</div>
                <div className="text-sm text-green-600">Resolved</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 border border-gray-200 rounded-md p-4">
                <div className="text-xl font-bold text-gray-700">{stats.totalAgents}</div>
                <div className="text-sm text-gray-600">Total Agents</div>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-md p-4">
                <div className="text-xl font-bold text-green-700">{stats.activeAgents}</div>
                <div className="text-sm text-green-600">Active Agents</div>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-md p-4">
                <div className="text-xl font-bold text-red-700">{stats.busyAgents}</div>
                <div className="text-sm text-red-600">Busy Agents</div>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
              <div className="text-xl font-bold text-yellow-700">{stats.waitingIssues}</div>
              <div className="text-sm text-yellow-600">Issues in Waitlist</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;