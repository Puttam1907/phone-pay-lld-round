import React, { useState, useEffect } from 'react';
import { issueService } from './services/IssueResolutionService';
import { CreateIssueData, CreateAgentData, IssueFilter, Issue, Agent } from './types';
import CustomerForm from './components/CustomerForm';
import AgentDashboard from './components/AgentDashboard';
import AdminPanel from './components/AdminPanel';
import { HeadphonesIcon, Users, Settings, Home, AlertCircle } from 'lucide-react';

function App() {
  const [activeView, setActiveView] = useState<'customer' | 'agent' | 'admin'>('customer');
  const [issues, setIssues] = useState<Issue[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [notification, setNotification] = useState<string>('');

  // Initialize with sample data
  useEffect(() => {
    // Add sample agents
    const agent1Id = issueService.addAgent({
      email: 'agent1@phonepe.com',
      name: 'Agent 1',
      expertise: ['Payment Related', 'Gold Related']
    });

    const agent2Id = issueService.addAgent({
      email: 'agent2@phonepe.com',
      name: 'Agent 2',
      expertise: ['Mutual Fund Related']
    });

    // Create sample issues
    const issue1Id = issueService.createIssue({
      transactionId: 'T1',
      issueType: 'Payment Related',
      subject: 'Payment Failed',
      description: 'My payment failed but money is debited',
      email: 'testUser1@test.com'
    });

    const issue2Id = issueService.createIssue({
      transactionId: 'T2',
      issueType: 'Mutual Fund Related',
      subject: 'Purchase Failed',
      description: 'Unable to purchase Mutual Fund',
      email: 'testUser2@test.com'
    });

    const issue3Id = issueService.createIssue({
      transactionId: 'T3',
      issueType: 'Payment Related',
      subject: 'Payment Failed',
      description: 'My payment failed but money is debited',
      email: 'testUser2@test.com'
    });

    // Assign issues
    issueService.assignIssue(issue1Id);
    issueService.assignIssue(issue2Id);
    issueService.assignIssue(issue3Id);

    // Update state
    setIssues(issueService.getIssues());
    setAgents(issueService.getAgents());

    showNotification(`Sample data loaded: ${agent1Id}, ${agent2Id} agents created and ${issue1Id}, ${issue2Id}, ${issue3Id} issues assigned`);
  }, []);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(''), 5000);
  };

  const handleCreateIssue = (data: CreateIssueData) => {
    const issueId = issueService.createIssue(data);
    const assigned = issueService.assignIssue(issueId);
    setIssues(issueService.getIssues());
    setAgents(issueService.getAgents());
    
    if (assigned) {
      showNotification(`Issue ${issueId} created and assigned successfully!`);
    } else {
      showNotification(`Issue ${issueId} created but no available agents found.`);
    }
  };

  const handleAddAgent = (data: CreateAgentData) => {
    const agentId = issueService.addAgent(data);
    setAgents(issueService.getAgents());
    showNotification(`Agent ${agentId} (${data.name}) added successfully!`);
  };

  const handleSearch = (filter: IssueFilter): Issue[] => {
    return issueService.getIssues(filter);
  };

  const handleResolveIssue = (issueId: string, resolution: string) => {
    issueService.resolveIssue(issueId, resolution);
    setIssues(issueService.getIssues());
    setAgents(issueService.getAgents());
    showNotification(`Issue ${issueId} resolved successfully!`);
  };

  const handleUpdateIssue = (issueId: string, status: string, resolution?: string) => {
    issueService.updateIssue(issueId, status as any, resolution);
    setIssues(issueService.getIssues());
    showNotification(`Issue ${issueId} updated successfully!`);
  };

  const getWaitlist = (agentId: string): Issue[] => {
    return issueService.getWaitlist(agentId);
  };

  const getWorkHistory = () => {
    return issueService.viewAgentsWorkHistory();
  };

  const getStats = () => {
    return issueService.getStats();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Home className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">PhonePe</h1>
                <p className="text-xs text-gray-500">Issue Resolution System</p>
              </div>
            </div>
            <nav className="flex space-x-1">
              <button
                onClick={() => setActiveView('customer')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors flex items-center space-x-2 ${
                  activeView === 'customer'
                    ? 'bg-blue-100 text-blue-700 border border-blue-200'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                }`}
              >
                <AlertCircle className="w-4 h-4" />
                <span>Customer</span>
              </button>
              <button
                onClick={() => setActiveView('agent')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors flex items-center space-x-2 ${
                  activeView === 'agent'
                    ? 'bg-blue-100 text-blue-700 border border-blue-200'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                }`}
              >
                <HeadphonesIcon className="w-4 h-4" />
                <span>Agent</span>
              </button>
              <button
                onClick={() => setActiveView('admin')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors flex items-center space-x-2 ${
                  activeView === 'admin'
                    ? 'bg-blue-100 text-blue-700 border border-blue-200'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Admin</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Notification */}
      {notification && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
          <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-green-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-green-700">{notification}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'customer' && (
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Customer Support</h2>
              <p className="text-gray-600">Report issues with your transactions and get help from our support team.</p>
            </div>
            <CustomerForm onCreateIssue={handleCreateIssue} />
          </div>
        )}

        {activeView === 'agent' && (
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Agent Dashboard</h2>
              <p className="text-gray-600">Manage assigned issues and help customers resolve their problems.</p>
            </div>
            <AgentDashboard
              agents={agents}
              issues={issues}
              onSearch={handleSearch}
              onResolveIssue={handleResolveIssue}
              onUpdateIssue={handleUpdateIssue}
              getWaitlist={getWaitlist}
            />
          </div>
        )}

        {activeView === 'admin' && (
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Admin Panel</h2>
              <p className="text-gray-600">Manage agents, view system statistics, and monitor work history.</p>
            </div>
            <AdminPanel
              agents={agents}
              onAddAgent={handleAddAgent}
              getWorkHistory={getWorkHistory}
              getStats={getStats}
            />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;