import { Issue, Agent, IssueFilter, CreateIssueData, CreateAgentData, IssueStatus, IssueType } from '../types';

class IssueResolutionService {
  private issues: Map<string, Issue> = new Map();
  private agents: Map<string, Agent> = new Map();
  private waitlists: Map<string, string[]> = new Map(); // agentId -> issueIds
  private issueCounter = 1;
  private agentCounter = 1;

  // Create a new issue
  createIssue(data: CreateIssueData): string {
    const issueId = `I${this.issueCounter++}`;
    const issue: Issue = {
      id: issueId,
      transactionId: data.transactionId,
      issueType: data.issueType,
      subject: data.subject,
      description: data.description,
      email: data.email,
      status: 'Open',
      createdAt: new Date(),
    };

    this.issues.set(issueId, issue);
    return issueId;
  }

  // Add a new agent
  addAgent(data: CreateAgentData): string {
    const agentId = `A${this.agentCounter++}`;
    const agent: Agent = {
      id: agentId,
      email: data.email,
      name: data.name,
      expertise: data.expertise,
      workHistory: [],
      isActive: true,
    };

    this.agents.set(agentId, agent);
    this.waitlists.set(agentId, []);
    return agentId;
  }

  // Assign issue to an available agent
  assignIssue(issueId: string): boolean {
    const issue = this.issues.get(issueId);
    if (!issue || issue.status !== 'Open') {
      return false;
    }

    // Find available agents with matching expertise
    const availableAgents = Array.from(this.agents.values()).filter(
      agent => agent.isActive && 
               agent.expertise.includes(issue.issueType) && 
               !agent.currentIssue
    );

    if (availableAgents.length > 0) {
      // Assign to agent with least work history (load balancing)
      const selectedAgent = availableAgents.reduce((prev, current) => 
        prev.workHistory.length <= current.workHistory.length ? prev : current
      );

      issue.assignedTo = selectedAgent.id;
      issue.status = 'In Progress';
      selectedAgent.currentIssue = issueId;
      selectedAgent.workHistory.push(issueId);

      this.issues.set(issueId, issue);
      this.agents.set(selectedAgent.id, selectedAgent);
      return true;
    } else {
      // Add to waitlist of any agent with matching expertise
      const expertAgents = Array.from(this.agents.values()).filter(
        agent => agent.isActive && agent.expertise.includes(issue.issueType)
      );

      if (expertAgents.length > 0) {
        const selectedAgent = expertAgents.reduce((prev, current) => {
          const prevWaitlist = this.waitlists.get(prev.id) || [];
          const currentWaitlist = this.waitlists.get(current.id) || [];
          return prevWaitlist.length <= currentWaitlist.length ? prev : current;
        });

        const waitlist = this.waitlists.get(selectedAgent.id) || [];
        waitlist.push(issueId);
        this.waitlists.set(selectedAgent.id, waitlist);
        issue.status = 'Waiting';
        this.issues.set(issueId, issue);
        return true;
      }
    }

    return false;
  }

  // Get issues based on filter
  getIssues(filter: IssueFilter = {}): Issue[] {
    const allIssues = Array.from(this.issues.values());
    
    return allIssues.filter(issue => {
      if (filter.email && issue.email !== filter.email) return false;
      if (filter.issueId && issue.id !== filter.issueId) return false;
      if (filter.type && issue.issueType !== filter.type) return false;
      if (filter.status && issue.status !== filter.status) return false;
      if (filter.agentId && issue.assignedTo !== filter.agentId) return false;
      return true;
    });
  }

  // Update issue status and resolution
  updateIssue(issueId: string, status: IssueStatus, resolution?: string): boolean {
    const issue = this.issues.get(issueId);
    if (!issue) return false;

    issue.status = status;
    if (resolution) {
      issue.resolution = resolution;
    }

    this.issues.set(issueId, issue);
    return true;
  }

  // Resolve an issue
  resolveIssue(issueId: string, resolution: string): boolean {
    const issue = this.issues.get(issueId);
    if (!issue) return false;

    issue.status = 'Resolved';
    issue.resolution = resolution;
    issue.resolvedAt = new Date();

    // Free up the agent and assign next issue from waitlist
    if (issue.assignedTo) {
      const agent = this.agents.get(issue.assignedTo);
      if (agent) {
        agent.currentIssue = undefined;
        
        // Check waitlist for next issue
        const waitlist = this.waitlists.get(agent.id) || [];
        if (waitlist.length > 0) {
          const nextIssueId = waitlist.shift()!;
          const nextIssue = this.issues.get(nextIssueId);
          if (nextIssue) {
            nextIssue.assignedTo = agent.id;
            nextIssue.status = 'In Progress';
            agent.currentIssue = nextIssueId;
            agent.workHistory.push(nextIssueId);
            this.issues.set(nextIssueId, nextIssue);
          }
          this.waitlists.set(agent.id, waitlist);
        }
        
        this.agents.set(agent.id, agent);
      }
    }

    this.issues.set(issueId, issue);
    return true;
  }

  // View agents work history
  viewAgentsWorkHistory(): { agent: Agent; issues: Issue[] }[] {
    return Array.from(this.agents.values()).map(agent => ({
      agent,
      issues: agent.workHistory.map(issueId => this.issues.get(issueId)!).filter(Boolean)
    }));
  }

  // Get all agents
  getAgents(): Agent[] {
    return Array.from(this.agents.values());
  }

  // Get agent by ID
  getAgent(agentId: string): Agent | undefined {
    return this.agents.get(agentId);
  }

  // Get waitlist for agent
  getWaitlist(agentId: string): Issue[] {
    const waitlist = this.waitlists.get(agentId) || [];
    return waitlist.map(issueId => this.issues.get(issueId)!).filter(Boolean);
  }

  // Get stats
  getStats() {
    const issues = Array.from(this.issues.values());
    const agents = Array.from(this.agents.values());
    
    return {
      totalIssues: issues.length,
      openIssues: issues.filter(i => i.status === 'Open').length,
      inProgressIssues: issues.filter(i => i.status === 'In Progress').length,
      resolvedIssues: issues.filter(i => i.status === 'Resolved').length,
      waitingIssues: issues.filter(i => i.status === 'Waiting').length,
      totalAgents: agents.length,
      activeAgents: agents.filter(a => a.isActive).length,
      busyAgents: agents.filter(a => a.currentIssue).length,
    };
  }
}

export const issueService = new IssueResolutionService();