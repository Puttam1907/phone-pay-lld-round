package com.phonepe.issueresolution.models;

/**
 * Filter criteria for searching issues
 */
public class IssueFilter {
    private String email;
    private String issueId;
    private IssueType type;
    private IssueStatus status;
    private String agentId;

    public IssueFilter() {}

    public IssueFilter(String email, String issueId, IssueType type, IssueStatus status, String agentId) {
        this.email = email;
        this.issueId = issueId;
        this.type = type;
        this.status = status;
        this.agentId = agentId;
    }

    // Getters and Setters
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getIssueId() { return issueId; }
    public void setIssueId(String issueId) { this.issueId = issueId; }

    public IssueType getType() { return type; }
    public void setType(IssueType type) { this.type = type; }

    public IssueStatus getStatus() { return status; }
    public void setStatus(IssueStatus status) { this.status = status; }

    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) { this.agentId = agentId; }
}