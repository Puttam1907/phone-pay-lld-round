package com.phonepe.issueresolution.strategies;

import com.phonepe.issueresolution.models.Agent;
import com.phonepe.issueresolution.models.Issue;
import java.util.List;
import java.util.Optional;

/**
 * Assignment strategy that assigns issues in round-robin fashion
 */
public class RoundRobinAssignmentStrategy implements AssignmentStrategy {
    private int currentIndex = 0;

    @Override
    public Optional<Agent> assignIssue(Issue issue, List<Agent> availableAgents) {
        List<Agent> eligibleAgents = availableAgents.stream()
                .filter(agent -> agent.canHandle(issue.getIssueType()) && agent.isAvailable())
                .toList();

        if (eligibleAgents.isEmpty()) {
            return Optional.empty();
        }

        Agent selectedAgent = eligibleAgents.get(currentIndex % eligibleAgents.size());
        currentIndex = (currentIndex + 1) % eligibleAgents.size();

        return Optional.of(selectedAgent);
    }
}