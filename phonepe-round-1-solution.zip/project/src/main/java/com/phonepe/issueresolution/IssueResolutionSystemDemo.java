package com.phonepe.issueresolution;

import com.phonepe.issueresolution.models.*;
import com.phonepe.issueresolution.services.IssueResolutionService;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Demo class to demonstrate the functionality of the Issue Resolution System
 * This simulates the exact example provided in the problem statement
 */
public class IssueResolutionSystemDemo {
    
    public static void main(String[] args) {
        System.out.println("=== PhonePe Issue Resolution System Demo ===\n");
        
        IssueResolutionService service = new IssueResolutionService();
        
        // Demo 1: Create Issues
        System.out.println("1. Creating Issues:");
        String issue1 = service.createIssue("T1", IssueType.PAYMENT_RELATED, 
                "Payment Failed", "My payment failed but money is debited", "testUser1@test.com");
        
        String issue2 = service.createIssue("T2", IssueType.MUTUAL_FUND_RELATED, 
                "Purchase Failed", "Unable to purchase Mutual Fund", "testUser2@test.com");
        
        String issue3 = service.createIssue("T3", IssueType.PAYMENT_RELATED, 
                "Payment Failed", "My payment failed but money is debited", "testUser2@test.com");
        
        System.out.println();
        
        // Demo 2: Add Agents
        System.out.println("2. Adding Agents:");
        String agent1 = service.addAgent("agent1@test.com", "Agent 1", 
                Arrays.asList(IssueType.PAYMENT_RELATED, IssueType.GOLD_RELATED));
        
        String agent2 = service.addAgent("agent2@test.com", "Agent 2", 
                Arrays.asList(IssueType.MUTUAL_FUND_RELATED));
        
        System.out.println();
        
        // Demo 3: Assign Issues
        System.out.println("3. Assigning Issues:");
        service.assignIssue(issue1);
        service.assignIssue(issue2);
        service.assignIssue(issue3); // This should go to waitlist as Agent 1 is busy
        
        System.out.println();
        
        // Demo 4: Search Issues by Email
        System.out.println("4. Searching Issues by Email (testUser2@test.com):");
        IssueFilter emailFilter = new IssueFilter();
        emailFilter.setEmail("testUser2@test.com");
        List<Issue> issuesByEmail = service.getIssues(emailFilter);
        issuesByEmail.forEach(System.out::println);
        
        System.out.println();
        
        // Demo 5: Search Issues by Type
        System.out.println("5. Searching Issues by Type (Payment Related):");
        IssueFilter typeFilter = new IssueFilter();
        typeFilter.setType(IssueType.PAYMENT_RELATED);
        List<Issue> issuesByType = service.getIssues(typeFilter);
        issuesByType.forEach(System.out::println);
        
        System.out.println();
        
        // Demo 6: Update Issue Status
        System.out.println("6. Updating Issue Status:");
        service.updateIssue(issue3, IssueStatus.IN_PROGRESS, "Waiting for payment confirmation");
        
        System.out.println();
        
        // Demo 7: Resolve Issue
        System.out.println("7. Resolving Issue:");
        service.resolveIssue(issue3, "Payment Failed debited amount will get reversed");
        
        System.out.println();
        
        // Demo 8: View Agents Work History
        System.out.println("8. Agents Work History:");
        Map<String, List<Issue>> workHistory = service.viewAgentsWorkHistory();
        workHistory.forEach((agentId, issues) -> {
            System.out.println(agentId + " -> {" + 
                    issues.stream().map(Issue::getId).reduce((a, b) -> a + ", " + b).orElse("") + "}");
        });
        
        System.out.println();
        
        // Demo 9: Additional Functionality - System Statistics
        System.out.println("9. System Statistics:");
        printSystemStats(service);
        
        System.out.println("\n=== Demo Completed Successfully ===");
    }
    
    private static void printSystemStats(IssueResolutionService service) {
        Map<String, Issue> allIssues = service.getAllIssues();
        Map<String, Agent> allAgents = service.getAllAgents();
        
        long openIssues = allIssues.values().stream()
                .filter(issue -> issue.getStatus() == IssueStatus.OPEN)
                .count();
        
        long inProgressIssues = allIssues.values().stream()
                .filter(issue -> issue.getStatus() == IssueStatus.IN_PROGRESS)
                .count();
        
        long resolvedIssues = allIssues.values().stream()
                .filter(issue -> issue.getStatus() == IssueStatus.RESOLVED)
                .count();
        
        long waitingIssues = allIssues.values().stream()
                .filter(issue -> issue.getStatus() == IssueStatus.WAITING)
                .count();
        
        long busyAgents = allAgents.values().stream()
                .filter(agent -> !agent.isAvailable())
                .count();
        
        System.out.println("Total Issues: " + allIssues.size());
        System.out.println("Open Issues: " + openIssues);
        System.out.println("In Progress Issues: " + inProgressIssues);
        System.out.println("Resolved Issues: " + resolvedIssues);
        System.out.println("Waiting Issues: " + waitingIssues);
        System.out.println("Total Agents: " + allAgents.size());
        System.out.println("Busy Agents: " + busyAgents);
        System.out.println("Available Agents: " + (allAgents.size() - busyAgents));
    }
}