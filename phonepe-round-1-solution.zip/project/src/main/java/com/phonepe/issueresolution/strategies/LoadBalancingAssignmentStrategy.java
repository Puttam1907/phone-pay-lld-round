package com.phonepe.issueresolution.strategies;

import com.phonepe.issueresolution.models.Agent;
import com.phonepe.issueresolution.models.Issue;
import java.util.List;
import java.util.Optional;

/**
 * Assignment strategy that assigns issues to agents with the least workload
 */
public class LoadBalancingAssignmentStrategy implements AssignmentStrategy {
    
    @Override
    public Optional<Agent> assignIssue(Issue issue, List<Agent> availableAgents) {
        if (availableAgents.isEmpty()) {
            return Optional.empty();
        }

        // Find agent with minimum work history (load balancing)
        Agent selectedAgent = availableAgents.stream()
                .filter(agent -> agent.canHandle(issue.getIssueType()) && agent.isAvailable())
                .min((a1, a2) -> Integer.compare(a1.getWorkHistory().size(), a2.getWorkHistory().size()))
                .orElse(null);

        return Optional.ofNullable(selectedAgent);
    }
}