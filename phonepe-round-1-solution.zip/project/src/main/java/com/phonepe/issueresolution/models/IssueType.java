package com.phonepe.issueresolution.models;

/**
 * Enum representing different types of issues that can be raised
 */
public enum IssueType {
    PAYMENT_RELATED("Payment Related"),
    MUTUAL_FUND_RELATED("Mutual Fund Related"),
    GOLD_RELATED("Gold Related"),
    INSURANCE_RELATED("Insurance Related");

    private final String displayName;

    IssueType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}