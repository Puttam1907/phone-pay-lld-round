package com.phonepe.issueresolution.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Represents a customer service agent in the system
 */
public class Agent {
    private String id;
    private String email;
    private String name;
    private Set<IssueType> expertise;
    private String currentIssueId;
    private List<String> workHistory;
    private boolean isActive;

    public Agent(String id, String email, String name, Set<IssueType> expertise) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.expertise = expertise;
        this.workHistory = new ArrayList<>();
        this.isActive = true;
    }

    public boolean canHandle(IssueType issueType) {
        return expertise.contains(issueType);
    }

    public boolean isAvailable() {
        return isActive && currentIssueId == null;
    }

    public void assignIssue(String issueId) {
        this.currentIssueId = issueId;
        this.workHistory.add(issueId);
    }

    public void completeCurrentIssue() {
        this.currentIssueId = null;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Set<IssueType> getExpertise() { return expertise; }
    public void setExpertise(Set<IssueType> expertise) { this.expertise = expertise; }

    public String getCurrentIssueId() { return currentIssueId; }
    public void setCurrentIssueId(String currentIssueId) { this.currentIssueId = currentIssueId; }

    public List<String> getWorkHistory() { return workHistory; }
    public void setWorkHistory(List<String> workHistory) { this.workHistory = workHistory; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    @Override
    public String toString() {
        return String.format("Agent{id='%s', name='%s', email='%s', expertise=%s, " +
                           "currentIssue='%s', workHistoryCount=%d}", 
                           id, name, email, expertise, currentIssueId, workHistory.size());
    }
}