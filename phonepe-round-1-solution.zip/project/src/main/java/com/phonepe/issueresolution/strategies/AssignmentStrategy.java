package com.phonepe.issueresolution.strategies;

import com.phonepe.issueresolution.models.Agent;
import com.phonepe.issueresolution.models.Issue;
import java.util.List;
import java.util.Optional;

/**
 * Strategy interface for assigning issues to agents
 */
public interface AssignmentStrategy {
    /**
     * Assigns an issue to an available agent based on the strategy
     * @param issue The issue to be assigned
     * @param availableAgents List of available agents who can handle this issue type
     * @return Optional containing the selected agent, or empty if no suitable agent found
     */
    Optional<Agent> assignIssue(Issue issue, List<Agent> availableAgents);
}