package com.phonepe.issueresolution.models;

import java.time.LocalDateTime;

/**
 * Represents a customer issue/complaint in the system
 */
public class Issue {
    private String id;
    private String transactionId;
    private IssueType issueType;
    private String subject;
    private String description;
    private String customerEmail;
    private IssueStatus status;
    private String resolution;
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;
    private String assignedAgentId;

    public Issue(String id, String transactionId, IssueType issueType, 
                 String subject, String description, String customerEmail) {
        this.id = id;
        this.transactionId = transactionId;
        this.issueType = issueType;
        this.subject = subject;
        this.description = description;
        this.customerEmail = customerEmail;
        this.status = IssueStatus.OPEN;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public IssueType getIssueType() { return issueType; }
    public void setIssueType(IssueType issueType) { this.issueType = issueType; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCustomerEmail() { return customerEmail; }
    public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }

    public IssueStatus getStatus() { return status; }
    public void setStatus(IssueStatus status) { this.status = status; }

    public String getResolution() { return resolution; }
    public void setResolution(String resolution) { this.resolution = resolution; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }

    public String getAssignedAgentId() { return assignedAgentId; }
    public void setAssignedAgentId(String assignedAgentId) { this.assignedAgentId = assignedAgentId; }

    @Override
    public String toString() {
        return String.format("Issue{id='%s', transactionId='%s', type=%s, subject='%s', " +
                           "description='%s', email='%s', status=%s}", 
                           id, transactionId, issueType, subject, description, customerEmail, status);
    }
}