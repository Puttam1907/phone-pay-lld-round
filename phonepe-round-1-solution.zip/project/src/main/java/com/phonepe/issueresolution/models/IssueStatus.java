package com.phonepe.issueresolution.models;

/**
 * Enum representing different statuses an issue can have
 */
public enum IssueStatus {
    OPEN("Open"),
    IN_PROGRESS("In Progress"),
    WAITING("Waiting"),
    RESOLVED("Resolved");

    private final String displayName;

    IssueStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}