package com.phonepe.issueresolution.services;

import com.phonepe.issueresolution.models.*;
import com.phonepe.issueresolution.strategies.AssignmentStrategy;
import com.phonepe.issueresolution.strategies.LoadBalancingAssignmentStrategy;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Main service class for handling issue resolution operations
 * Implements all core functionality for the PhonePe Issue Resolution System
 */
public class IssueResolutionService {
    
    // Thread-safe data structures for concurrent access
    private final Map<String, Issue> issues = new ConcurrentHashMap<>();
    private final Map<String, Agent> agents = new ConcurrentHashMap<>();
    private final Map<String, Queue<String>> agentWaitlists = new ConcurrentHashMap<>();
    
    // Counters for generating unique IDs
    private int issueCounter = 1;
    private int agentCounter = 1;
    
    // Strategy for assigning issues to agents
    private AssignmentStrategy assignmentStrategy;

    public IssueResolutionService() {
        this.assignmentStrategy = new LoadBalancingAssignmentStrategy();
    }

    public IssueResolutionService(AssignmentStrategy assignmentStrategy) {
        this.assignmentStrategy = assignmentStrategy;
    }

    /**
     * Creates a new issue in the system
     * @param transactionId The transaction ID associated with the issue
     * @param issueType The type of issue
     * @param subject Brief subject of the issue
     * @param description Detailed description of the issue
     * @param email Customer's email address
     * @return The ID of the created issue
     */
    public String createIssue(String transactionId, IssueType issueType, 
                             String subject, String description, String email) {
        String issueId = "I" + issueCounter++;
        Issue issue = new Issue(issueId, transactionId, issueType, subject, description, email);
        issues.put(issueId, issue);
        
        System.out.println("Issue " + issueId + " created against transaction \"" + transactionId + "\"");
        return issueId;
    }

    /**
     * Adds a new agent to the system
     * @param agentEmail Agent's email address
     * @param agentName Agent's name
     * @param expertiseList List of issue types the agent can handle
     * @return The ID of the created agent
     */
    public String addAgent(String agentEmail, String agentName, List<IssueType> expertiseList) {
        String agentId = "A" + agentCounter++;
        Set<IssueType> expertise = new HashSet<>(expertiseList);
        Agent agent = new Agent(agentId, agentEmail, agentName, expertise);
        
        agents.put(agentId, agent);
        agentWaitlists.put(agentId, new LinkedList<>());
        
        System.out.println("Agent " + agentId + " created");
        return agentId;
    }

    /**
     * Assigns an issue to an available agent or adds to waitlist
     * @param issueId The ID of the issue to assign
     * @return true if assigned successfully, false otherwise
     */
    public boolean assignIssue(String issueId) {
        Issue issue = issues.get(issueId);
        if (issue == null || issue.getStatus() != IssueStatus.OPEN) {
            System.out.println("Issue " + issueId + " not found or not in OPEN status");
            return false;
        }

        // Get available agents who can handle this issue type
        List<Agent> availableAgents = agents.values().stream()
                .filter(agent -> agent.canHandle(issue.getIssueType()) && agent.isAvailable())
                .collect(Collectors.toList());

        // Try to assign using the strategy
        Optional<Agent> selectedAgent = assignmentStrategy.assignIssue(issue, availableAgents);
        
        if (selectedAgent.isPresent()) {
            Agent agent = selectedAgent.get();
            issue.setAssignedAgentId(agent.getId());
            issue.setStatus(IssueStatus.IN_PROGRESS);
            agent.assignIssue(issueId);
            
            System.out.println("Issue " + issueId + " assigned to agent " + agent.getId());
            return true;
        } else {
            // Add to waitlist of agent with matching expertise and shortest waitlist
            Optional<Agent> waitlistAgent = findBestWaitlistAgent(issue.getIssueType());
            if (waitlistAgent.isPresent()) {
                Agent agent = waitlistAgent.get();
                agentWaitlists.get(agent.getId()).offer(issueId);
                issue.setStatus(IssueStatus.WAITING);
                
                System.out.println("Issue " + issueId + " added to waitlist of Agent " + agent.getId());
                return true;
            }
        }

        System.out.println("No suitable agent found for issue " + issueId);
        return false;
    }

    /**
     * Retrieves issues based on filter criteria
     * @param filter Filter criteria for searching issues
     * @return List of issues matching the filter
     */
    public List<Issue> getIssues(IssueFilter filter) {
        return issues.values().stream()
                .filter(issue -> matchesFilter(issue, filter))
                .collect(Collectors.toList());
    }

    /**
     * Updates an issue's status and resolution
     * @param issueId The ID of the issue to update
     * @param status New status for the issue
     * @param resolution Resolution details (optional)
     * @return true if updated successfully, false otherwise
     */
    public boolean updateIssue(String issueId, IssueStatus status, String resolution) {
        Issue issue = issues.get(issueId);
        if (issue == null) {
            System.out.println("Issue " + issueId + " not found");
            return false;
        }

        issue.setStatus(status);
        if (resolution != null && !resolution.trim().isEmpty()) {
            issue.setResolution(resolution);
        }

        System.out.println(issueId + " status updated to " + status);
        return true;
    }

    /**
     * Resolves an issue and assigns next issue from waitlist if available
     * @param issueId The ID of the issue to resolve
     * @param resolution Resolution details
     * @return true if resolved successfully, false otherwise
     */
    public boolean resolveIssue(String issueId, String resolution) {
        Issue issue = issues.get(issueId);
        if (issue == null) {
            System.out.println("Issue " + issueId + " not found");
            return false;
        }

        issue.setStatus(IssueStatus.RESOLVED);
        issue.setResolution(resolution);
        issue.setResolvedAt(LocalDateTime.now());

        // Free up the agent and assign next issue from waitlist
        if (issue.getAssignedAgentId() != null) {
            Agent agent = agents.get(issue.getAssignedAgentId());
            if (agent != null) {
                agent.completeCurrentIssue();
                
                // Check waitlist for next issue
                Queue<String> waitlist = agentWaitlists.get(agent.getId());
                if (!waitlist.isEmpty()) {
                    String nextIssueId = waitlist.poll();
                    Issue nextIssue = issues.get(nextIssueId);
                    if (nextIssue != null) {
                        nextIssue.setAssignedAgentId(agent.getId());
                        nextIssue.setStatus(IssueStatus.IN_PROGRESS);
                        agent.assignIssue(nextIssueId);
                        
                        System.out.println("Next issue " + nextIssueId + " assigned to agent " + agent.getId());
                    }
                }
            }
        }

        System.out.println(issueId + " issue marked resolved");
        return true;
    }

    /**
     * Returns the work history of all agents
     * @return Map of agent ID to list of issues they worked on
     */
    public Map<String, List<Issue>> viewAgentsWorkHistory() {
        Map<String, List<Issue>> workHistory = new HashMap<>();
        
        for (Agent agent : agents.values()) {
            List<Issue> agentIssues = agent.getWorkHistory().stream()
                    .map(issues::get)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            workHistory.put(agent.getId(), agentIssues);
        }
        
        return workHistory;
    }

    // Helper methods

    private Optional<Agent> findBestWaitlistAgent(IssueType issueType) {
        return agents.values().stream()
                .filter(agent -> agent.canHandle(issueType))
                .min((a1, a2) -> Integer.compare(
                        agentWaitlists.get(a1.getId()).size(),
                        agentWaitlists.get(a2.getId()).size()
                ));
    }

    private boolean matchesFilter(Issue issue, IssueFilter filter) {
        if (filter.getEmail() != null && !filter.getEmail().equals(issue.getCustomerEmail())) {
            return false;
        }
        if (filter.getIssueId() != null && !filter.getIssueId().equals(issue.getId())) {
            return false;
        }
        if (filter.getType() != null && !filter.getType().equals(issue.getIssueType())) {
            return false;
        }
        if (filter.getStatus() != null && !filter.getStatus().equals(issue.getStatus())) {
            return false;
        }
        if (filter.getAgentId() != null && !filter.getAgentId().equals(issue.getAssignedAgentId())) {
            return false;
        }
        return true;
    }

    // Getter methods for testing and monitoring
    public Map<String, Issue> getAllIssues() {
        return new HashMap<>(issues);
    }

    public Map<String, Agent> getAllAgents() {
        return new HashMap<>(agents);
    }

    public Map<String, Queue<String>> getAgentWaitlists() {
        return new HashMap<>(agentWaitlists);
    }

    public void setAssignmentStrategy(AssignmentStrategy strategy) {
        this.assignmentStrategy = strategy;
    }
}