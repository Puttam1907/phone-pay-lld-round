package com.phonepe.issueresolution;

import com.phonepe.issueresolution.models.*;
import com.phonepe.issueresolution.services.IssueResolutionService;
import com.phonepe.issueresolution.strategies.RoundRobinAssignmentStrategy;

import java.util.Arrays;
import java.util.List;

/**
 * Test class for IssueResolutionService
 * Demonstrates various test scenarios and edge cases
 */
public class IssueResolutionServiceTest {
    
    public static void main(String[] args) {
        System.out.println("=== Running Issue Resolution Service Tests ===\n");
        
        testBasicFunctionality();
        testWaitlistFunctionality();
        testFilteringFunctionality();
        testEdgeCases();
        testDifferentAssignmentStrategies();
        
        System.out.println("=== All Tests Completed ===");
    }
    
    private static void testBasicFunctionality() {
        System.out.println("Test 1: Basic Functionality");
        IssueResolutionService service = new IssueResolutionService();
        
        // Create agents
        String agent1 = service.addAgent("agent1@test.com", "Agent 1", 
                Arrays.asList(IssueType.PAYMENT_RELATED));
        
        // Create issue
        String issue1 = service.createIssue("T1", IssueType.PAYMENT_RELATED, 
                "Test Issue", "Test Description", "customer@test.com");
        
        // Assign issue
        boolean assigned = service.assignIssue(issue1);
        assert assigned : "Issue should be assigned successfully";
        
        // Resolve issue
        boolean resolved = service.resolveIssue(issue1, "Test resolution");
        assert resolved : "Issue should be resolved successfully";
        
        System.out.println("✓ Basic functionality test passed\n");
    }
    
    private static void testWaitlistFunctionality() {
        System.out.println("Test 2: Waitlist Functionality");
        IssueResolutionService service = new IssueResolutionService();
        
        // Create one agent
        String agent1 = service.addAgent("agent1@test.com", "Agent 1", 
                Arrays.asList(IssueType.PAYMENT_RELATED));
        
        // Create two issues
        String issue1 = service.createIssue("T1", IssueType.PAYMENT_RELATED, 
                "Issue 1", "Description 1", "customer1@test.com");
        String issue2 = service.createIssue("T2", IssueType.PAYMENT_RELATED, 
                "Issue 2", "Description 2", "customer2@test.com");
        
        // Assign both issues
        service.assignIssue(issue1); // Should be assigned
        service.assignIssue(issue2); // Should go to waitlist
        
        // Resolve first issue
        service.resolveIssue(issue1, "Resolution 1");
        
        // Check if second issue is now assigned
        Issue secondIssue = service.getAllIssues().get(issue2);
        assert secondIssue.getStatus() == IssueStatus.IN_PROGRESS : "Second issue should be in progress";
        
        System.out.println("✓ Waitlist functionality test passed\n");
    }
    
    private static void testFilteringFunctionality() {
        System.out.println("Test 3: Filtering Functionality");
        IssueResolutionService service = new IssueResolutionService();
        
        // Create issues
        service.createIssue("T1", IssueType.PAYMENT_RELATED, 
                "Issue 1", "Description 1", "customer1@test.com");
        service.createIssue("T2", IssueType.MUTUAL_FUND_RELATED, 
                "Issue 2", "Description 2", "customer2@test.com");
        service.createIssue("T3", IssueType.PAYMENT_RELATED, 
                "Issue 3", "Description 3", "customer1@test.com");
        
        // Test email filter
        IssueFilter emailFilter = new IssueFilter();
        emailFilter.setEmail("customer1@test.com");
        List<Issue> emailResults = service.getIssues(emailFilter);
        assert emailResults.size() == 2 : "Should find 2 issues for customer1@test.com";
        
        // Test type filter
        IssueFilter typeFilter = new IssueFilter();
        typeFilter.setType(IssueType.PAYMENT_RELATED);
        List<Issue> typeResults = service.getIssues(typeFilter);
        assert typeResults.size() == 2 : "Should find 2 payment related issues";
        
        System.out.println("✓ Filtering functionality test passed\n");
    }
    
    private static void testEdgeCases() {
        System.out.println("Test 4: Edge Cases");
        IssueResolutionService service = new IssueResolutionService();
        
        // Test assigning non-existent issue
        boolean assigned = service.assignIssue("INVALID_ID");
        assert !assigned : "Should not assign non-existent issue";
        
        // Test resolving non-existent issue
        boolean resolved = service.resolveIssue("INVALID_ID", "Resolution");
        assert !resolved : "Should not resolve non-existent issue";
        
        // Test assigning issue with no suitable agents
        String issue1 = service.createIssue("T1", IssueType.INSURANCE_RELATED, 
                "Insurance Issue", "Description", "customer@test.com");
        boolean assignedWithoutAgent = service.assignIssue(issue1);
        assert !assignedWithoutAgent : "Should not assign issue without suitable agent";
        
        System.out.println("✓ Edge cases test passed\n");
    }
    
    private static void testDifferentAssignmentStrategies() {
        System.out.println("Test 5: Different Assignment Strategies");
        
        // Test with Round Robin strategy
        IssueResolutionService service = new IssueResolutionService(new RoundRobinAssignmentStrategy());
        
        // Create multiple agents
        service.addAgent("agent1@test.com", "Agent 1", Arrays.asList(IssueType.PAYMENT_RELATED));
        service.addAgent("agent2@test.com", "Agent 2", Arrays.asList(IssueType.PAYMENT_RELATED));
        
        // Create and assign multiple issues
        String issue1 = service.createIssue("T1", IssueType.PAYMENT_RELATED, 
                "Issue 1", "Description 1", "customer1@test.com");
        String issue2 = service.createIssue("T2", IssueType.PAYMENT_RELATED, 
                "Issue 2", "Description 2", "customer2@test.com");
        
        service.assignIssue(issue1);
        service.assignIssue(issue2);
        
        // Both issues should be assigned to different agents
        Issue firstIssue = service.getAllIssues().get(issue1);
        Issue secondIssue = service.getAllIssues().get(issue2);
        
        assert !firstIssue.getAssignedAgentId().equals(secondIssue.getAssignedAgentId()) : 
                "Issues should be assigned to different agents with round robin";
        
        System.out.println("✓ Different assignment strategies test passed\n");
    }
}