export interface Issue {
  id: string;
  transactionId: string;
  issueType: IssueType;
  subject: string;
  description: string;
  email: string;
  status: IssueStatus;
  resolution?: string;
  createdAt: Date;
  assignedTo?: string;
  resolvedAt?: Date;
}

export interface Agent {
  id: string;
  email: string;
  name: string;
  expertise: IssueType[];
  currentIssue?: string;
  workHistory: string[];
  isActive: boolean;
}

export type IssueType = 
  | 'Payment Related' 
  | 'Mutual Fund Related' 
  | 'Gold Related' 
  | 'Insurance Related';

export type IssueStatus = 'Open' | 'In Progress' | 'Resolved' | 'Waiting';

export interface IssueFilter {
  email?: string;
  issueId?: string;
  type?: IssueType;
  status?: IssueStatus;
  agentId?: string;
}

export interface CreateIssueData {
  transactionId: string;
  issueType: IssueType;
  subject: string;
  description: string;
  email: string;
}

export interface CreateAgentData {
  email: string;
  name: string;
  expertise: IssueType[];
}